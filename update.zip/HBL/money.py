
#Credit to Duckling
#Gives you 9999999 coins (Splatoon 2.8.0, HBL Gecko)

tcp = TCPGecko(ip)
tcp.pokemem(0x12CE31A0,9999999)
tcp.s.close()
print("Done.")
