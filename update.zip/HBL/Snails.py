 
#Credit to Duckling
#Gives you 999 Super Sea Snails (Splatoon 2.8.0, HBL Gecko)
 
tcp = TCPGecko(ip)
tcp.pokemem(0x12CD8C24, 0xFFFFFFFF) #progression
tcp.pokemem(0x12CE31B4, 999) #snails
tcp.s.close()
print("Done.")
