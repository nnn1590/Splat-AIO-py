
#Credit to Riru2025
#Gives you rank S+ 99 (Splatoon 2.8.0, HBL Gecko)

tcp = TCPGecko(ip)
tcp.pokemem(0x12CD8C24,0xFFFFFFFF) #progression
tcp.pokemem(0x12CE31AC,10) #rank (0 is C-, 1 is C, 2 is C+, and so on to 10 is S+)
tcp.pokemem(0x12CE31B0,99) #rank number
tcp.s.close()
print("Done.")
