
#Credit to Riru2025
#Unlocks all minigames (Splatoon 2.8.0, HBL Gecko)

tcp = TCPGecko(ip)
tcp.pokemem(0x12CD9C40, 0x000F0000)
tcp.s.close()
print("Done.")
