#Menu, in hopes that os.system() will function properly
geckoent = 1
cver = int(open("./Resources/setup/ver.txt", "r").read())
choice = True
while choice:
    absolutely_unsigned_variable = os.system("cls")
    print("Splat AIO v%d(for Splatoon 2.8.0) -- Wii U IP: %s" % (cver, ip))
    print("Original AIO by iAqua, rewritten by seresaa")
    print("""
Please don't just blindly use these hacks. Your chances of getting banned
vary depending on which of these hacks you use and how you use them.
""")
    print("Please press a button followed by ENTER:")
    print("""
<1> Octohax+, with Squid Form       <9> Unlock All Arcade Games
<2> Octohax+, with  Octo Form       <a> Amiibohax
                                    <b> Colorizer (Requires Java)
<3> Set Money                       <c> SplatHax
<4> Set Snails
<5> Set Level                       <t> TCPGecko.NET
<6> Set Rank                        <i> Scan for IP
<7> All (Safely) Obtainable Gear             
<8> All Obtainable Weapons          <v> Options

                                    <ENTER> Exit\n\n""")
    
    choice = raw_input(">> ")

    #Normal Octohax
    if choice == "1":
        if geckoent == 1:
            execfile("./Resources/run/OVH/octohax+.py")
        else:
            execfile("./Resources/run/HBL/octohax+.py")

    #Octoform Octohax so people stop saying it doesn't work.
    elif choice == "2":
        if geckoent == 1:
            execfile("./Resources/run/OVH/octocto+.py")
        else:
            execfile("./Resources/run/HBL/octocto+.py")

    #Max Money.
    elif choice == "3":
        if geckoent == 1:
            execfile("./Resources/run/OVH/money.py")
        else:
            execfile("./Resources/run/HBL/money.py")

    #Max Snails.
    elif choice == "4":
        if geckoent == 1:
            execfile("./Resources/run/OVH/Snails.py")
        else:
            execfile("./Resources/run/HBL/Snails.py")

    #Level 50.
    elif choice == "5":
        if geckoent == 1:
            execfile("./Resources/run/OVH/MaxStats1.py")
        else:
            execfile("./Resources/run/HBL/MaxStats1.py")

    #S+ 99
    elif choice == "6":
        if geckoent == 1:
            execfile("./Resources/run/OVH/MaxStats2.py")
        else:
            execfile("./Resources/run/HBL/MaxStats2.py")

    #All Gear.
    elif choice == "7":
        if geckoent == 1:
            execfile("./Resources/run/OVH/AllGear.py")
        else:
            execfile("./Resources/run/HBL/AllGear.py")

    #All Weapons.
    elif choice == "8":
        if geckoent == 1:
            execfile("./Resources/run/OVH/Weapons.py")
        else:
            execfile("./Resources/run/HBL/Weapons.py")

    #All Minigames.
    elif choice == "9":
        if geckoent == 1:
            execfile("./Resources/run/OVH/AllMinigames.py")
        else:
            execfile("./Resources/run/HBL/AllMinigames.py")

    #Amiibohax
    elif choice == "a":
    
        subprocess.call("./Resources/run/exe/amiibohax.exe")
        

    #FREAKING COLORIZER
    elif choice == "b":
            os.system(r".\Resources\run\exe\gudWrapper.jar .\Resources\run\exe\SplatoonColorizer.27.gud")
            

    #SplatHax
    elif choice == "c":
        subprocess.call("./Resources/run/exe/Splathax.exe")

    #TCPGecko
    elif choice == "t":
        if geckoent == 1:
            subprocess.call("./Resources/run/Gecko/Gecko_dNet.exe")
        else:
            absolutely_unused_variable = os.system("cls")
            print("""Note: The Homebrew Launcher version of TCPGecko has its addresses in different
areas from the loadiine.ovh version. If you can't find an address you know,
first try adding 0x00008000 onto it. e.g. 12CD0D80 becomes 12CD8D80""")
            subprocess.call("./Resources/run/Gecko/Gecko_dNet.exe")

    #IP Scanner
    elif choice == "i":
        subprocess.call("./Resources/run/exe/ipscan24.exe")

    #Options
    elif choice == "v":
        execfile("./Resources/run/main/options.py")
