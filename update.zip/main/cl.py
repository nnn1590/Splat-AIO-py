import urllib, urllib2

clc = True
while clc:
    absolutely_unused_variable = os.system("cls")

    print("""Press a number given to view changes, or anything else to go back.

    <1> v2
    <2> v3
    <3> v4
    """)

    clc = raw_input(">> ")

    if clc == "1":
        info = urllib2.urlopen("https://raw.githubusercontent.com/seresaa/Splat-AIO/master/cl/ch2.txt").read()

    elif clc == "2":
        info = urllib2.urlopen("https://raw.githubusercontent.com/seresaa/Splat-AIO/master/cl/ch3.txt").read()

    elif clc == "3":
        info = urllib2.urlopen("https://raw.githubusercontent.com/seresaa/Splat-AIO/master/cl/ch4.txt").read()

    else:
        break

    absolutely_unused_variable = os.system("cls")
    print(info)
    print("")
    print("Use any button to return.\n")
    raw_input()

    clc = True
