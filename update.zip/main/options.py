choice2 = True
while choice2:
    absolutely_unused_variable = os.system("cls")
          

    if geckoent == 1:
        print("<s> Switch to Homebrew Launcher Gecko. Amiibohax, Splathax,")
        print("and Colorizer won't work if you're using this.\n")
    else:
        print("<s> Switch back to Internet Browser Gecko.\n")
    print("<1> Check for Update")
    print("<2> Change IP address (Currently %s)\n" %ip)
    print("<ENTER> Go Back\n\n")

    choice2 = raw_input(">> ")
    if choice2 == "1":
        execfile("./Resources/setup/update_beta.py")

    elif choice2 == "2":
        absolutely_unused_variable = os.system("cls")
        print("Please type in your new IP address.\n")
        fresh_ip = raw_input(">> ")
        save = open("./Resources/setup/ip.txt", "w")
        save.write(fresh_ip)
        save.close()
        ip = fresh_ip

    elif choice2 == "s":
        if geckoent == 1:
            geckoent = 2
        else:
            geckoent = 1
