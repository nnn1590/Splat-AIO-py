import urllib2
choice2 = True
while choice2:
    absolutely_unused_variable = os.system("cls")
          

    if geckoent == 1:
        print("""

Press <1> to check for updates.
Press <2> to update your IP address.
Press <3> to view the changelog list.

Press <4> to view the Modding Hub thread.

Press <s> to switch to Homebrew Launcher Gecko mode.
     Different scripts will be used to match its
     addresses. Colorhax and Splathax will not work.

Press <c> to look at the credits.
<ENTER> to go back.\n""")

    if geckoent == 2:
        print("""

Press <1> to check for updates.
Press <2> to update your IP address.
Press <3> to view the changelog list.

Press <4> to view the Modding Hub thread.

Press <s> to switch to Internet Browser Gecko mode.

Press <c> to look at credits.
Press <ENTER> to go back.\n""")

    choice2 = raw_input(">> ")
    if choice2 == "1":
        execfile("./Resources/setup/update_beta.py")

    elif choice2 == "2":
        absolutely_unused_variable = os.system("cls")
        print("Please type in your new IP address.\n")
        fresh_ip = raw_input(">> ")
        save = open("./Resources/setup/ip.txt", "w")
        save.write(fresh_ip)
        save.close()
        ip = fresh_ip

    elif choice2 == "3":
        execfile("./Resources/run/main/cl.py")

    elif choice2 == "s":
        if geckoent == 1:
            geckoent = 2
        else:
            geckoent = 1

    elif choice2 == "4":
        os.system("start \"\" http://gbatemp.net/threads/splatoon-modding-hub.425670/")

    elif choice2 == "c":
        absolutely_unused_variable = os.system("cls")
        cr = open("./Resources/run/extra/credits.txt", "r").read()
        print(cr)
        print("\n")
        raw_input("Press ENTER to return.")
