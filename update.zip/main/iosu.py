import time
import webbrowser

print("Finding Wii U...")
time.sleep(3)
print("Found Wii U!")
time.sleep(1/3)
print("Starting IOSU hax")
time.sleep(10)
print("IOSU hax activated!")
webbrowser.open("https://www.kfc.com/")
input()