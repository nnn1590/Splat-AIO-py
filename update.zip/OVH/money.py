
#Credit to Duckling
#Gives you 9999999 coins (Splatoon 2.8.0, OVH Gecko)

tcp = TCPGecko(ip)
tcp.pokemem(0x12CDB1A0,9999999)
tcp.s.close()
print("Done.")
