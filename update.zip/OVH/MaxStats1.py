 
#Separated; rank hack is in MaxStats2
#Credit to Riru2025
#Gives you level 50 (Splatoon 2.8.0, OVH Gecko)
 
tcp = TCPGecko(ip)
tcp.pokemem(0x12CD0C24, 0xFFFFFFFF) #progression
tcp.pokemem(0x12CDB1A8, 49) #level (+1 in-game)
tcp.pokemem(0x12CDB1A4, 0) #level points
tcp.s.close()
print("Done.")
