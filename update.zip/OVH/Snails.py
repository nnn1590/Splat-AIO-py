#Credit to Duckling
#Gives you 999 Super Sea Snails (Splatoon 2.8.0, OVH Gecko)

tcp = TCPGecko(ip)
tcp.pokemem(0x12CDB1B4, 999)
tcp.s.close()
print("Done.")
