
# Timerhax for Splatoon v2.10.0
A Python script for adjusting the timer in Splatoon in 3 different modes:

- Recon
- Battle Dojo
- Amiibo timed challenges

**Requirements:**

This script requires Python 2.7.
That's it really.


**How to use**:

Download the all the files as zip and extract it on your computer.
Run the timer.bat to run the script and then follow the instructions provided.

**Credits:**

Script structure based on Seresaa's Splat-AIO. I couldn't make this program without it.
